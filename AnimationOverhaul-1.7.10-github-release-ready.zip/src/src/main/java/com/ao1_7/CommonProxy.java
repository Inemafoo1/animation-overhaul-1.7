package com.ao1_7;

import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.event.FMLInitializationEvent;

public class CommonProxy {
    public void preInit(FMLPreInitializationEvent evt) {
        // registrar configs/arquivos comuns
    }

    public void init(FMLInitializationEvent evt) {
        // registradores de servidor/comuns
    }
}
